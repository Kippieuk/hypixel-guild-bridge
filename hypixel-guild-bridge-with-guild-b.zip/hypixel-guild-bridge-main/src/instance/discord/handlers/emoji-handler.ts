import { hash } from 'node:crypto'
import fs from 'node:fs/promises'

import type { ApplicationEmoji, ApplicationEmojiManager, Client } from 'discord.js'

import type { InstanceType } from '../../../common/application-event.js'
import SubInstance from '../../../common/sub-instance'
import type { EmojiConfig } from '../../../core/discord/discord-emojis'
import { AllEmojis } from '../common/discord-config.js'
import type DiscordInstance from '../discord-instance.js'

export default class EmojiHandler extends SubInstance<DiscordInstance, InstanceType.Discord, Client> {
  public emojiByName = new Map<string, ApplicationEmoji>()

  override registerEvents(client: Client): void {
    client.on('clientReady', (readyClient) => {
      void this.registerEmojis(readyClient.application.emojis).catch(
        this.errorHandler.promiseCatch('registering emojis in guild')
      )
    })
  }

  private async registerEmojis(manager: ApplicationEmojiManager): Promise<void> {
    const registeredEmojis = await manager.fetch()
    const savedEmojis = this.application.core.discordEmojis.getAll()
    const toSaveEmojis: EmojiConfig[] = []

    for (const emoji of AllEmojis) {
      this.logger.trace(`Checking emoji ${emoji.name}`)
      const imageData = await fs.readFile(emoji.path)
      const imageHash = hash('sha256', imageData, 'hex')
      const registeredEmoji = registeredEmojis.find((existingEmoji) => existingEmoji.name === emoji.name)
      const savedEmoji = savedEmojis.find((savedEmoji) => savedEmoji.name === emoji.name)

      if (registeredEmoji !== undefined) {
        if (savedEmoji?.hash === imageHash) {
          this.logger.trace(`Emoji ${emoji.name} is registered already and matches the resource file. skipping...`)
          toSaveEmojis.push({ name: emoji.name, hash: imageHash })
          continue
        }

        if (savedEmoji === undefined) {
          this.logger.warn(
            `The emoji ${emoji.name} is registered but is somehow not saved in the configuration file. ` +
              'There is no way to prove the emoji validity. ' +
              'The registered emoji will be deleted and replaced with the emoji from the resource file ' +
              'before properly saving it in the configuration for future checking.'
          )
        } else {
          this.logger.warn('Registered emoji does not match the emoji in the resource file')
          this.logger.warn('Deleting the registered emoji before trying to register the new the new one')
        }

        await manager.delete(registeredEmoji)
      }

      this.logger.info(`Registering emoji=${emoji.path} under the name ${emoji.name}`)
      await manager.create({ name: emoji.name, attachment: imageData })

      toSaveEmojis.push({ name: emoji.name, hash: imageHash })
    }

    this.application.core.discordEmojis.replaceAll(toSaveEmojis)

    const fetched = await manager.fetch()
    this.emojiByName.clear()
    for (const [, emoji] of fetched) {
      if (emoji.name) this.emojiByName.set(emoji.name, emoji)
    }
  }
}
